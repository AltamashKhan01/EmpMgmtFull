import { Component } from '@angular/core';
import { Employee } from '../employee';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  imports: [FormsModule, CommonModule],
  templateUrl: './update-employee.component.html',
  styleUrl: './update-employee.component.css'
})
export class UpdateEmployeeComponent {

  id: number = 0;
  employee: Employee = new Employee();
  // Add a property to store initial values
  private initialEmployeeState: Employee = {
    id: 0,
    firstName: '',
    lastName: '',
    emailId: '',
    mobile: 0,
    address: '',
    role: '',
    salary: 0
  };

  constructor(private employeeService: EmployeeService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.employeeService.getEmployeeById(this.id).subscribe(data => {
      this.employee = data;

      // Store initial state
      this.initialEmployeeState = { ...this.employee };
    },
      error => console.log(error));
  }

  goToEmployeeList() {
    this.router.navigate(['/employees']);
  }

  onSubmit() {
    this.employeeService.updateEmployee(this.id, this.employee).subscribe(data => {
      alert("Employee Updated Sucessfully!");
      this.goToEmployeeList();
    },
      error => console.log(error));
  }

  resetForm(): void {
    this.employee = { ...this.initialEmployeeState };
  }

}
