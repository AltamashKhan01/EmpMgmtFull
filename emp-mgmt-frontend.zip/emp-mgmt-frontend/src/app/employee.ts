export class Employee {
    id: number = 0;
    firstName: string | undefined;
    lastName: string | undefined;
    emailId: string | undefined;
    mobile: number | undefined;
    address: string | undefined;
    role: string | undefined;
    salary: number | undefined;
}
